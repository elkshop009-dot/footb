export const matches = [
  {
    id: 1,
    teamA: 'Milan',
    teamB: 'Atalanta',
    logoA: 'https://images.fotmob.com/image_resources/logo/teamlogo/8564_small.png',
    logoB: 'https://images.fotmob.com/image_resources/logo/teamlogo/8524_small.png',
    matchTime: '19:45 PM CET',
    imageback: 'https://sportcdns.live/news-2/68973dd8f24a441bf2424d142c67d4ec7baabb42be0cab201fc5c31f4cf5545f.png',
  },
  {
    id: 2,
    teamA: 'Real Madrid',
    teamB: 'Athletic Club',
    logoA: 'https://images.fotmob.com/image_resources/logo/teamlogo/8633_small.png',
    logoB: 'https://images.fotmob.com/image_resources/logo/teamlogo/8315_small.png',
    matchTime: '20:00 PM CET',
    imageback: 'https://icdn.football-espana.net/wp-content/uploads/2024/12/Alex-Berenguer.jpg',
  },
];